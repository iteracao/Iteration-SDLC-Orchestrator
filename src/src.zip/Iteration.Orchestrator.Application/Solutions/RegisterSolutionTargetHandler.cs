﻿using Iteration.Orchestrator.Domain.Solutions;
using Iteration.Orchestrator.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Iteration.Orchestrator.Application.Solutions;

public sealed class RegisterSolutionTargetHandler
{
    private readonly AppDbContext _db;

    public RegisterSolutionTargetHandler(AppDbContext db)
    {
        _db = db;
    }

    public async Task<Guid> HandleAsync(RegisterSolutionTargetCommand command, CancellationToken ct)
    {
        var existing = await _db.SolutionTargets
            .FirstOrDefaultAsync(x => x.Code == command.Code, ct);

        if (existing is not null)
        {
            existing.Name = command.Name;
            existing.RepositoryPath = command.RepositoryPath;
            existing.MainSolutionFile = command.MainSolutionFile;
            existing.ProfileCode = command.ProfileCode;
            existing.SolutionOverlayCode = command.SolutionOverlayCode;

            await _db.SaveChangesAsync(ct);
            return existing.Id;
        }

        var target = new SolutionTarget
        {
            Id = Guid.NewGuid(),
            Code = command.Code,
            Name = command.Name,
            RepositoryPath = command.RepositoryPath,
            MainSolutionFile = command.MainSolutionFile,
            ProfileCode = command.ProfileCode,
            SolutionOverlayCode = command.SolutionOverlayCode,
            IsActive = true,
            CreatedUtc = DateTime.UtcNow
        };

        _db.SolutionTargets.Add(target);
        await _db.SaveChangesAsync(ct);

        return target.Id;
    }
}