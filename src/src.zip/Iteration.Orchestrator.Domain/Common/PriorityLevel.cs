namespace Iteration.Orchestrator.Domain.Common;

public enum PriorityLevel
{
    Low = 1,
    Medium = 2,
    High = 3,
    Critical = 4
}
